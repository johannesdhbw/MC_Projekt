SystemStar 3 Demo
=================
Softstar Systems
www.SoftstarSystems.com
(603) 672-0987


INTRODUCTION TO SYSTEMSTAR
==========================
SystemStar is an estimation tool based on the COCOMO II and COSYSMO 2.0
models.

SystemStar 3.0 runs under Windows XP, Windows 7, and Windows 8.

Please note that you should calibrate COSYSMO to your own environment to get
reliable results.  Use "Calico for SystemStar" to do the local calibration
of the COSYSMO model.


SYSTEMSTAR INSTALLATION
=======================
If your copy of SystemStar came on a CD, the installation procedure will
start automatically when you insert the CD.

If you were sent the file "SystemStar_Demo_302.exe", just double-click
it to start the installation.


RESTRICTIONS ON THE DEMO VERSION
================================
The demo version of SystemStar has a restriction built into it: the total
size for a COSYSMO estimate is limited to 100 requirements; the total size
for a COCOMO estimate is limited to 5,000 SLOC.  You can experiment with
all of the SystemStar commands, generate all of the SystemStar reports, create
any number of estimates, and develop estimates with any number of components,
but you won't be able to create estimates for large systems.

File | Load Model is disabled in the demo version of SystemStar.

You may make and distribute copies of the demo version of SystemStar.


SYSTEMSTAR LICENSE
==================
SystemStar is licensed, not sold.  The standard license is for 12 months.
Contact us at (603) 672-0987 or Sales@SoftstarSystems.com to extend 
your license.


RELEASE NOTES
=============
1)  The SystemStar window describes the "current estimate".  You can create
    other estimates with "New | Estimate".

2)  Press Control-P to print any window on the printer.

3)  You can write an Excel macro that takes data from cells in a spreadsheet,
    sends the data as inputs to SystemStar, and then extracts answers from the
    SystemStar reports to be displayed in your spreadsheet.

    Call us at (603) 672-0987 if you want more information on this topic.

4)  "Calico for SystemStar" includes the ability to edit all of the parameters
    that make up a COCOMO or COSYSMO estimating model, including:
	a) The model's effort & schedule distributions
	b) The cost drivers
	c) The effort multipliers
	d) The names of the phases and activities

    "Calico for SystemStar" also calibrates the COCOMO or COSYSMO equation to
    your historical data.

    After you use "Calico for SystemStar" to create a model file, you can
    use SystemStar's File | Open Model to use your new model for estimating.

5) SystemStar 3.02 supports the COSYSMO 2.0 Reuse Model.

6) SystemStar 3.02 supports Monte Carlo sizing.
